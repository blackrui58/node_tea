
//注册app
var app = angular.module('app',['ngRoute','in_theaters','coming_soon','top250']);

// 配置路由表
app.config(['$routeProvider',function ($routeProvider) {
	$routeProvider.when('/in_theaters/:id',{
		templateUrl: 'in_theaters/index.html',
		controller: 'in_theatersCtrl'
	}).when('/coming_soon/1',{
		templateUrl: 'coming_soon/index.html',
		controller: 'coming_soonCtrl'
	}).when('/top250/1',{
		templateUrl: 'top250/index.html',
		controller: 'top250Ctrl'
	}).otherwise({redirectTo: '/in_theaters/1'});
}]);