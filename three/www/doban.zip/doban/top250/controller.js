//自己创建的专属于正在热映的app
var top250App = angular.module('top250',[]);

top250App.controller('top250Ctrl',['$scope',function ($scope){
	
}]);