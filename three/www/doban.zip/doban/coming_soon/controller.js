//自己创建的专属于即将上映的app
var coming_soonApp = angular.module('coming_soon',[]);

coming_soonApp.controller('coming_soonCtrl',['$scope',function ($scope){
	
}]);